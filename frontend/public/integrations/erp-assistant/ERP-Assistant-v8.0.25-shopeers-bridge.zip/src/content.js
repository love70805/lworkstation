(function () {
    'use strict';

    if (window.__erpAssistantCostV8) return;
    window.__erpAssistantCostV8 = true;

    const API_BASE = 'https://www.zhuolinkeji.cn';
    const LIST_PATH = '/purchase/purchase/v1/purchase-order-page';
    const DETAIL_PATH = '/purchase/purchase/v1/purchase-order-details';
    const SKU_PATH = '/purchase/product/v1/product-info-sku';
    const PURCHASE_PAGE_PATH = '/view/system/purchaseOrderModule/purchasingManagement.html';
    const MAX_RECORDS = 3;
    const MAX_CONCURRENT_DETAIL = 8;
    const MAX_CONCURRENT_SKU = 5;
    const REQUEST_TIMEOUT = 20000;
    const MAX_LIST_PAGES = 1000;
    const PREFERRED_PAGE_SIZE = 50;
    const RETRY_COUNT = 2;
    const CACHE_TTL = 10 * 60 * 1000;
    const RESULT_CACHE_TTL = 30 * 60 * 1000;
    const RESULT_CACHE_KEY = 'latest_cost_result_v6';
    const PREFIX = '[ERP Assistant]';
    const EXTENSION_VERSION = '8.0.25';
    const resultPolicy = window.ShopeersErpResultPolicy;
    const requestContextPolicy = window.ShopeersErpRequestContext;
    if (!resultPolicy || !requestContextPolicy) {
        console.error(PREFIX, '未加载成本结果或请求上下文规则模块，停止运行以避免导出未校验映射。');
        return;
    }

    const catalogCollector = window.ShopeersErpCatalogCollector?.create({ apiGet: apiGetRetry, readWarehouseEvidence, policy: resultPolicy, getCache, setCache });

    const nativeFetch = typeof window.fetch === 'function' ? window.fetch.bind(window) : null;
    let capturedListUrl = '';
    let capturedQueryCapturedAt = '';
    let activeRun = null;
    let lastResults = [];
    let lastMeta = null;
    let lastWarehouseEvidence = null;
    let searchText = '';
    let toastTimer = null;
    let pageSizeObserver = null;
    let pageSizeObservedBody = null;
    let uiRepairObserver = null;
    let uiRepairTimer = null;
    let documentEventsBound = false;
    let bridgeConnection = 'connecting';
    let statusReportPending = false;
    let statusReportQueued = false;
    let currentPageUrl = window.location.href;
    let querySnapshotRestoreAllowed = isPurchasePage();
    let erpSessionState = 'unknown';
    const isTopFrame = window.top === window;
    const expandedRows = new Set();

    function supportedErpUrl(value) {
        try {
            const url = new URL(value, window.location.href);
            return url.protocol === 'https:' && (url.hostname === 'zhuolinkeji.cn' || url.hostname.endsWith('.zhuolinkeji.cn')) ? url : null;
        } catch { return null; }
    }

    function isPurchasePage() {
        return supportedErpUrl(window.location.href)?.pathname === PURCHASE_PAGE_PATH;
    }

    function needsLogin() {
        return erpSessionState === 'login_required' || /(?:^|\/)(?:login|signin)(?:[/.]|$)/i.test(window.location.pathname)
            || [...document.querySelectorAll('input[type="password"]')].some((input) => input.getClientRects().length > 0);
    }

    function activePurchaseFrame() {
        if (!isTopFrame || isPurchasePage()) return null;
        return [...document.querySelectorAll('iframe')].find((frame) => {
            if (!frame.getClientRects().length) return false;
            const style = window.getComputedStyle(frame);
            if (style.display === 'none' || style.visibility === 'hidden') return false;
            let url;
            try { url = supportedErpUrl(frame.contentWindow.location.href); } catch { url = supportedErpUrl(frame.getAttribute('src')); }
            return url?.pathname === PURCHASE_PAGE_PATH;
        }) || null;
    }

    function renderPageContext() {
        const status = document.getElementById('erpa-page-context');
        if (!status) return;
        const available = isPurchasePage() && !needsLogin();
        const connection = bridgeConnection === 'connected' ? '工作台已连接' : bridgeConnection === 'connecting' ? '正在连接工作台' : '工作台暂未连接，采集证据可由扩展后台保留';
        const condition = needsLogin() ? '请先登录 ERP，再打开采购管理查询。' : !available ? '请进入采购管理并查询，再预览 SKU 成本。' : capturedListUrl ? '采购查询已捕获，可采集成本证据。' : '请先在采购管理点击“查询”，再预览成本。';
        status.replaceChildren();
        const copy = document.createElement('span');
        copy.textContent = '助手已加载 · ' + connection + '。' + condition;
        status.appendChild(copy);
        if (!available && !needsLogin()) {
            const link = document.createElement('a');
            link.className = 'erpa-button';
            link.href = new URL(PURCHASE_PAGE_PATH, window.location.origin).href;
            link.textContent = '打开采购管理';
            status.appendChild(link);
        }
        const recalculate = document.getElementById('erpa-recalculate');
        if (recalculate) recalculate.disabled = !available || !capturedListUrl || Boolean(activeRun);
        const supplement = document.getElementById('erpa-supplement-catalog');
        if (supplement) supplement.disabled = !available || Boolean(activeRun) || !catalogCollector;
        const retry = document.getElementById('erpa-retry-delivery');
        if (retry) retry.disabled = !available;
    }

    function previewScopeLabel() {
        const period = resultPolicy.validLedgerPeriod(lastMeta?.ledgerPeriod);
        return period ? `台账月份：${period} · 采用当月及以前采购` : '台账月份待关联 · 暂不计算预览成本';
    }

    async function readPreviewContext(querySkcs, queryCapturedAt) {
        const bridge = window.ShopeersErpDeliveryBridge;
        if (!bridge?.previewContext) return { ledgerPeriod: null, message: '请更新扩展并从工作台选择台账后重新查询。' };
        const settled = await requestContextPolicy.settleRequestContext(bridge.previewContext({ querySkcs, queryCapturedAt }), 5000);
        const response = settled.context;
        return response?.ok && resultPolicy.validLedgerPeriod(response.ledgerPeriod)
            ? { ledgerPeriod: response.ledgerPeriod }
            : { ledgerPeriod: null, message: response?.message || settled.error?.message || '未取得唯一台账月份，请回工作台选择台账后重新查询。' };
    }

    async function restorePreviewContext(cached) {
        const marker = lastMeta;
        const context = await readPreviewContext(cached.meta?.querySkcs || extractQuerySkcs(cached.meta?.filters), cached.queryCapturedAt || cached.meta?.queryCapturedAt);
        if (activeRun || lastMeta !== marker) return;
        lastResults = resultPolicy.previewForLedger(cached.results, cached.warehouseEvidence, context.ledgerPeriod);
        lastMeta = { ...lastMeta, ...buildWarningMeta(lastResults), ledgerPeriod: context.ledgerPeriod, previewContextMessage: context.message };
        renderResults();
        renderStatus();
        renderAnomalyBanner();
    }

    class CostError extends Error {
        constructor(message, details) {
            super(message);
            this.name = 'CostError';
            this.details = details || '';
        }
    }

    function captureListRequest(rawUrl) {
        if (!rawUrl || !isPurchasePage()) return;
        try {
            const url = supportedErpUrl(rawUrl);
            if (url?.pathname === LIST_PATH) {
                capturedListUrl = url.href;
                capturedQueryCapturedAt = new Date().toISOString();
                const filters = {};
                url.searchParams.forEach((value, key) => { if (key !== 'page') filters[key] = value; });
                updateIdleStatus();
                renderPageContext();
                void reportExtensionStatus();
                schedulePageSizeUpgrade();
                console.info(PREFIX, '已捕获采购查询条件');
            }
        } catch (error) {
            console.warn(PREFIX, '无法解析采购请求 URL', error);
        }
    }

    window.addEventListener('shopeers:erp-v8-query-captured', (event) => {
        captureListRequest(event?.detail?.url);
    });

    function ensurePageSize50() {
        if (!isPurchasePage()) return false;
        const selects = [...document.querySelectorAll('.layui-laypage-limits select')];
        const select = selects.find((item) => [...item.options].some((option) => {
            const value = String(option.value || '').trim();
            const label = String(option.textContent || '').trim();
            return value === '50' || /^50(?:条|\/页)?$/.test(label);
        }));
        if (!select) return false;
        const option = [...select.options].find((item) => {
            const value = String(item.value || '').trim();
            const label = String(item.textContent || '').trim();
            return value === '50' || /^50(?:条|\/页)?$/.test(label);
        });
        if (!option) return false;
        if (String(select.value) === String(option.value)) return true;
        select.value = option.value;
        select.dispatchEvent(new Event('change', { bubbles: true }));
        console.info(PREFIX, '已将 ERP 页面分页切换为 50 条/页');
        return true;
    }

    function schedulePageSizeUpgrade() {
        if (!isPurchasePage()) return;
        if (ensurePageSize50()) return;
        if (!document.body || !window.MutationObserver) return;
        if (pageSizeObserver && pageSizeObservedBody !== document.body) {
            pageSizeObserver.disconnect();
            pageSizeObserver = null;
            pageSizeObservedBody = null;
        }
        if (pageSizeObserver) return;
        pageSizeObserver = new MutationObserver(() => {
            if (ensurePageSize50()) {
                pageSizeObserver.disconnect();
                pageSizeObserver = null;
                pageSizeObservedBody = null;
            }
        });
        pageSizeObservedBody = document.body;
        pageSizeObserver.observe(document.body, { childList: true, subtree: true });
        window.setTimeout(() => {
            if (!pageSizeObserver) return;
            if (ensurePageSize50()) {
                pageSizeObserver.disconnect();
                pageSizeObserver = null;
                pageSizeObservedBody = null;
            }
        }, 3000);
    }

    function parseCapturedFilters() {
        if (!isPurchasePage() || needsLogin() || !capturedListUrl) {
            throw new CostError(
                '尚未捕获采购查询条件',
                '请先在采购管理页面点击“查询”，确认表格结果刷新后再进行核算。'
            );
        }

        const url = new URL(capturedListUrl, API_BASE);
        const filters = {};
        url.searchParams.forEach((value, key) => {
            if (key !== 'page') filters[key] = value;
        });
        return filters;
    }

    function buildUrl(path, params) {
        const url = new URL(path, API_BASE);
        Object.keys(params).forEach((key) => {
            const value = params[key];
            if (value !== '' && value !== undefined && value !== null) {
                url.searchParams.set(key, String(value));
            }
        });
        return url.href;
    }

    async function apiGet(path, params, parentSignal, context) {
        if (parentSignal?.aborted) throw parentSignal.reason || new DOMException('请求已中止', 'AbortError');
        if (parentSignal?.requestBudget != null && --parentSignal.requestBudget < 0) throw new CostError('资料请求超过预算', '请缩小查询范围后补充资料。');
        if (!nativeFetch) throw new CostError('当前页面不支持 fetch');

        const controller = new AbortController();
        let timedOut = false;
        const relayAbort = () => controller.abort(parentSignal.reason);
        if (parentSignal) {
            if (parentSignal.aborted) relayAbort();
            else parentSignal.addEventListener('abort', relayAbort, { once: true });
        }

        let rejectAbort;
        const aborted = new Promise((_, reject) => { rejectAbort = reject; });
        const onAbort = () => rejectAbort(controller.signal.reason || new DOMException('请求已中止', 'AbortError'));
        controller.signal.addEventListener('abort', onAbort, { once: true });
        if (controller.signal.aborted) onAbort();
        const slowId = window.setTimeout(() => setLoading('ERP 请求响应较慢', context + ' · 已等待8秒（每次最多20秒，可取消）', 5), 8000);
        const timeoutId = window.setTimeout(() => {
            timedOut = true;
            controller.abort();
        }, REQUEST_TIMEOUT);

        try {
            const response = await Promise.race([nativeFetch(buildUrl(path, params), {
                credentials: 'include',
                signal: controller.signal,
                headers: {
                    Accept: 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }), aborted]);

            if (response.status === 401 || response.status === 403) { erpSessionState = 'login_required'; throw Object.assign(new CostError('ERP 登录已失效', '请登录 ERP 并重新查询后重试。'), { code: 'ERP_LOGIN_REQUIRED' }); }
            if (!response.ok) {
                throw new CostError(context + '请求失败', 'HTTP ' + response.status + ' ' + response.statusText);
            }

            try {
                const body = await Promise.race([response.json(), aborted]);
                if (response.status === 401 || response.status === 403 || /登录|login|session.*expired/i.test(String(body?.msg || body?.message || ''))) {
                    erpSessionState = 'login_required';
                    throw Object.assign(new CostError('ERP 登录已失效', '请登录 ERP 并重新查询后重试。'), { code: 'ERP_LOGIN_REQUIRED' });
                }
                return body;
            } catch (error) {
                if (error instanceof CostError) throw error;
                throw new CostError(context + '返回了无效 JSON', error.message || String(error));
            }
        } catch (error) {
            if (timedOut) {
                throw new CostError(context + '请求超时', '超过 ' + REQUEST_TIMEOUT / 1000 + ' 秒，已中止该请求。');
            }
            if (parentSignal && parentSignal.aborted) {
                if (parentSignal.reason instanceof Error) throw parentSignal.reason;
                throw new DOMException('核算已取消', 'AbortError');
            }
            if (error instanceof CostError) throw error;
            throw new CostError(context + '请求失败', error.message || String(error));
        } finally {
            window.clearTimeout(timeoutId);
            window.clearTimeout(slowId);
            controller.signal.removeEventListener('abort', onAbort);
            if (parentSignal) parentSignal.removeEventListener('abort', relayAbort);
        }
    }

    function wait(ms) {
        return new Promise((resolve) => window.setTimeout(resolve, ms));
    }

    async function apiGetRetry(path, params, parentSignal, context) {
        let lastError = null;
        for (let attempt = 0; attempt <= RETRY_COUNT; attempt += 1) {
            if (parentSignal?.aborted) throw parentSignal.reason || new DOMException('核算已取消', 'AbortError');
            if (attempt) setLoading('请求较慢，正在重试', context + ' · 第 ' + attempt + '/' + RETRY_COUNT + ' 次重试（每次最多20秒，可取消）', 5);
            try {
                return await apiGet(path, params, parentSignal, context);
            } catch (error) {
                lastError = error;
                if (parentSignal && parentSignal.aborted) throw error;
                if (!isRetryableError(error)) throw error;
                if (attempt < RETRY_COUNT) await wait(500 * (attempt + 1));
            }
        }
        throw lastError;
    }

    function isRetryableError(error) {
        const text = String((error && error.message) || '') + ' ' + String((error && error.details) || '');
        return /超时|网络|连接|Failed to fetch|HTTP (429|5\d{2})/i.test(text);
    }

    function readCacheEntry(storageKey) {
        try {
            const raw = window.sessionStorage.getItem(storageKey);
            if (!raw) return null;
            const entry = JSON.parse(raw);
            const timestamp = Number(entry.timestamp ?? entry.ts);
            if (!entry || !Number.isFinite(timestamp) || Date.now() - timestamp > CACHE_TTL) return null;
            return entry.value ?? entry.data ?? null;
        } catch {
            return null;
        }
    }

    function getCache(key, legacyKey = key) {
        return readCacheEntry('erpAssistantV8_' + key) ?? readCacheEntry('skuApiCache_' + legacyKey);
    }

    function setCache(key, value) {
        try {
            window.sessionStorage.setItem('erpAssistantV8_' + key, JSON.stringify({ timestamp: Date.now(), value }));
        } catch {
            // Storage may be disabled; network path remains authoritative.
        }
    }

    function getResultCache() {
        try {
            const raw = window.localStorage.getItem('erpAssistantV8_' + RESULT_CACHE_KEY);
            if (!raw) return null;
            const entry = JSON.parse(raw);
            if (!entry || Date.now() - Number(entry.timestamp) > RESULT_CACHE_TTL) {
                window.localStorage.removeItem('erpAssistantV8_' + RESULT_CACHE_KEY);
                return null;
            }
            if (!Array.isArray(entry.results) || !entry.meta) return null;
            return entry;
        } catch {
            return null;
        }
    }

    function makeResultDeliveryId() {
        const random = globalThis.crypto?.randomUUID?.() || (Date.now() + '-' + Math.random().toString(16).slice(2));
        return 'ERP-RESULT-' + random;
    }

    function setResultCache(results, meta, warehouseEvidence, capturedUrl, resultDeliveryId, deliveryState = {}) {
        try {
            const queryCapturedAt = String(deliveryState.queryCapturedAt || deliveryState.registeredBefore || meta?.queryCapturedAt || meta?.registeredBefore || '').trim();
            window.localStorage.setItem('erpAssistantV8_' + RESULT_CACHE_KEY, JSON.stringify({
                timestamp: Date.now(),
                results,
                meta,
                warehouseEvidence,
                capturedUrl: capturedUrl || '',
                resultDeliveryId,
                createdAt: String(deliveryState.createdAt || '').trim() || new Date().toISOString(),
                queryCapturedAt,
                registeredBefore: queryCapturedAt,
                attemptsTotal: Math.max(0, Number(deliveryState.attemptsTotal || 0)),
                deliveryTerminal: Boolean(deliveryState.deliveryTerminal),
                importEnvelope: deliveryState.importEnvelope || null
            }));
        } catch {
            // Large result sets or disabled storage must not block核算。
        }
    }

    let lastImportEnvelope = null;
    function handleDeliveryStatus(detail = {}) {
        if (detail.resultDeliveryId) {
            const cached = getResultCache();
            if (cached && cached.resultDeliveryId === detail.resultDeliveryId) {
                if (detail.envelope) lastImportEnvelope = detail.envelope;
                setResultCache(cached.results, cached.meta, cached.warehouseEvidence, cached.capturedUrl, cached.resultDeliveryId, {
                    createdAt: detail.createdAt || cached.createdAt,
                    queryCapturedAt: detail.queryCapturedAt || detail.registeredBefore || cached.queryCapturedAt || cached.registeredBefore,
                    attemptsTotal: Math.max(Number(cached.attemptsTotal || 0), Number(detail.attemptsTotal || 0)),
                    deliveryTerminal: Boolean(cached.deliveryTerminal || detail.status === 'success' || detail.status === 'failed'),
                    importEnvelope: detail.envelope || cached.importEnvelope || null,
                });
            } else return;
        }
        const messages = {
            sending: '正在回传 Lworkstation 成本证据',
            success: '本机服务已接收成本证据，待工作台核对后发布',
            cached: '回传暂未成功，已缓存等待有限补发',
            failed: '成本证据回传失败，后台保留待处理证据'
        };
        const message = detail.message || messages[detail.status];
        if (message) showToast(message, detail.status === 'failed' ? 'error' : undefined);
    }

    function dispatchCostResults(results, meta, warehouseEvidence, resultDeliveryId, deliveryState = {}) {
        if (!Array.isArray(results)) return;
        const bridge = window.ShopeersErpDeliveryBridge;
        if (!bridge || typeof bridge.submit !== 'function') {
            console.warn(PREFIX, '隔离投递桥尚未就绪，本地预览、复制和 CSV 仍可使用。');
            return false;
        }
        const deliveryMeta = requestContextPolicy.deliverySourceMeta(meta);
        const queryCapturedAt = String(deliveryState.queryCapturedAt || deliveryState.registeredBefore || deliveryMeta.queryCapturedAt || deliveryMeta.registeredBefore || '').trim();
        handleDeliveryStatus({ status: 'sending', resultDeliveryId });
        void bridge.submit({
            results,
            meta: deliveryMeta,
            warehouseEvidence,
            resultDeliveryId,
            querySkcs: Array.isArray(deliveryMeta.querySkcs) ? deliveryMeta.querySkcs : [],
            createdAt: String(deliveryState.createdAt || '').trim(),
            queryCapturedAt,
            registeredBefore: queryCapturedAt
        }).then(handleDeliveryStatus, (error) => handleDeliveryStatus({
            status: 'cached',
            resultDeliveryId,
            message: error?.message || '隔离投递通道暂不可用，后台缓存会按上限补发。'
        }));
        return true;
    }

    function findNestedArray(value, depth = 0, visited = new Set()) {
        if (Array.isArray(value)) return value;
        if (!value || typeof value !== 'object' || depth > 4 || visited.has(value)) return null;
        visited.add(value);
        const keys = ['list', 'records', 'rows', 'items', 'data', 'result', 'skuList', 'skuInfoList', 'platformSkuList', 'purchaseOrders', 'details'];
        for (const key of keys) {
            const found = findNestedArray(value[key], depth + 1, visited);
            if (found) return found;
        }
        for (const child of Object.values(value)) {
            const found = findNestedArray(child, depth + 1, visited);
            if (found) return found;
        }
        return null;
    }

    function requireApiData(response, context) {
        if (!response || response.code !== 0) {
            const code = response && response.code !== undefined ? response.code : '缺失';
            const message = response && (response.msg || response.message);
            throw new CostError(context + '接口异常', '业务状态码：' + code + (message ? '\n' + message : ''));
        }
        if (!Array.isArray(response.data)) {
            throw new CostError(context + '数据格式异常', '接口 data 不是数组。');
        }
        return response.data;
    }

    function requireApiList(response, context) {
        if (!response || response.code !== 0) {
            const code = response && response.code !== undefined ? response.code : '缺失';
            const message = response && (response.msg || response.message);
            throw new CostError(context + '接口异常', '业务状态码：' + code + (message ? '\n' + message : ''));
        }
        const data = response.data;
        if (data == null || data === '' || (typeof data === 'object' && !Array.isArray(data) && Object.keys(data).length === 0)) return [];
        const list = findNestedArray(data);
        if (list) return list;
        if (typeof data === 'object') {
            const keys = Object.keys(data).slice(0, 20).join(', ');
            throw new CostError(context + '数据格式异常', '接口 data 不是可识别的列表。响应字段：' + (keys || '无'));
        }
        throw new CostError(context + '数据格式异常', '接口 data 不是数组或列表对象。');
    }

    function requireMappingData(response, context) {
        if (!response || response.code !== 0) {
            const code = response && response.code !== undefined ? response.code : '缺失';
            const message = response && (response.msg || response.message);
            throw new CostError(context + '接口异常', '业务状态码：' + code + (message ? '\n' + message : ''));
        }
        const data = response.data;
        if (data == null || data === '' || (typeof data === 'object' && !Array.isArray(data) && Object.keys(data).length === 0)) return [];
        const wrapped = findNestedArray(data);
        if (wrapped) return wrapped;
        if (data && typeof data === 'object') {
            const keys = Object.keys(data).slice(0, 20).join(', ');
            const platformSku = data.barcodeSkuid || data.barCodeSkuid || data.barCodeSkuId || data.barcodeSku || data.platformSku || data.platformSkuId || data.sku || data.skuId || data.sellerSku || data.skuCode;
            if (platformSku) return [data];
            throw new CostError(context + '数据格式异常', '未找到平台 SKU 列表或平台 SKU 字段。响应字段：' + (keys || '无'));
        }
        throw new CostError(context + '数据格式异常', '接口 data 为空或不是对象。');
    }

    async function mapConcurrent(items, limit, worker, run, onProgress) {
        const results = new Array(items.length);
        let cursor = 0;
        let completed = 0;
        let firstError = null;

        async function runner() {
            while (cursor < items.length && !firstError && !run.controller.signal.aborted) {
                const index = cursor++;
                try {
                    results[index] = await worker(items[index], index);
                    completed += 1;
                    if (onProgress) onProgress(completed, items.length);
                } catch (error) {
                    if (!firstError) {
                        firstError = error;
                        run.controller.abort(error);
                    }
                    throw error;
                }
            }
        }

        const workerCount = Math.max(1, Math.min(limit, items.length));
        try {
            await Promise.all(Array.from({ length: workerCount }, runner));
        } catch (error) {
            throw firstError || error;
        }
        if (run.controller.signal.aborted) throw run.controller.signal.reason || new DOMException('核算已取消', 'AbortError');
        return results;
    }

    function parseDateInfo(value) {
        return resultPolicy.purchaseDateInfo(value);
    }

    function selectCostRecords(records) {
        return records.slice(0, MAX_RECORDS);
    }

    function warningReasons(detail) {
        return Array.isArray(detail && detail.warningReasons)
            ? detail.warningReasons.filter(Boolean)
            : [];
    }

    function formatWarningReasons(reasons) {
        return (Array.isArray(reasons) ? reasons : [])
            .map((reason) => resultPolicy.costWarningLabel(reason))
            .filter(Boolean)
            .join('；');
    }

    function resultCostWarnings(result) {
        if (result && result.costWarnings) return result.costWarnings;
        return resultPolicy.summarizeCostWarnings(result && result.details);
    }

    function buildWarningMeta(results) {
        const summaries = (Array.isArray(results) ? results : []).map(resultCostWarnings);
        return {
            costWarningCount: summaries.reduce((sum, summary) => sum + Number(summary.count || 0), 0)
        };
    }

    function supplierName(record) {
        return String(record && (
            record.supplierName || record.supplier || record.supplierCompanyName || record.supplierFullName || record.supplierTitle
        ) || '').trim();
    }

    function supplierNameKey(value) {
        return String(value || '').normalize('NFKC').replace(/\s+/g, '').toLocaleUpperCase('zh-CN');
    }

    function resolveSupplier1688Links(detail, order) {
        const detailName = supplierName(detail);
        const orderName = supplierName(order);
        const name = detailName || orderName;
        if (!detail) return resultPolicy.extractSupplier1688Links(order, orderName);
        // An order can contain several products from one supplier. Product links
        // belong to this detail, never to another row found by supplier name.
        return resultPolicy.normalizeSupplier1688Links([
            { type: 'product', url: detail.productLink1688, supplierName: name },
            { type: 'product', url: detail.purchasingLink1688, supplierName: name },
            ...resultPolicy.extractSupplier1688Links(detail, name),
            ...(name && supplierNameKey(name) === supplierNameKey(orderName)
                ? resultPolicy.extractSupplier1688Links(order, orderName).filter(link => link.type === 'store') : []),
        ]);
    }

    function resolveSupplier1688Url(detail, order) {
        const name = supplierNameKey(supplierName(detail) || supplierName(order));
        const links = resolveSupplier1688Links(detail, order).filter(link => supplierNameKey(link.supplierName) === name);
        return links.find(link => link.type === 'product')?.url || '';
    }

    function withOrderContext(detail, order, purchaseOrderId) {
        return Object.assign({}, detail, {
            _purchaseOrderId: purchaseOrderId,
            _orderNo1688: String(order.purchaseOrderNo1688 || '').trim(),
            _purchaseOrderNo: String(order.purchaseOrderNo || '').trim(),
            _supplierName: supplierName(detail) || supplierName(order),
            _supplier1688Url: resolveSupplier1688Url(detail, order),
            _supplier1688Links: resolveSupplier1688Links(detail, order),
        });
    }

    function normalizeMappings(data) {
        return resultPolicy.normalizeMappings(data);
    }

    async function fetchAllOrders(filters, run) {
        setLoading('正在读取采购单', '读取第 1 页', 5);
        const capturedPageSize = Number(filters.limit);
        const fallbackPageSize = Number.isFinite(capturedPageSize) && capturedPageSize > 0 ? capturedPageSize : null;
        let pageSize = PREFERRED_PAGE_SIZE;
        let firstResponse;
        let usedFallback = false;
        try {
            firstResponse = await apiGetRetry(
                LIST_PATH,
                Object.assign({}, filters, { page: 1, limit: PREFERRED_PAGE_SIZE }),
                run.controller.signal,
                '采购列表第 1 页'
            );
        } catch (error) {
            if (run.controller.signal.aborted || !fallbackPageSize || fallbackPageSize === PREFERRED_PAGE_SIZE || !/HTTP 400|HTTP 422/.test(error.details || '')) throw error;
            usedFallback = true;
            pageSize = fallbackPageSize;
            firstResponse = await apiGetRetry(
                LIST_PATH,
                Object.assign({}, filters, { page: 1, limit: fallbackPageSize }),
                run.controller.signal,
                '采购列表第 1 页（回退页大小 ' + fallbackPageSize + '）'
            );
        }
        const firstPage = requireApiList(firstResponse, '采购列表第 1 页');
        const reportedCount = Number(firstResponse.count ?? firstResponse.total ?? firstResponse.totalCount);
        const hasReportedCount = Number.isFinite(reportedCount) && reportedCount > 0;
        const rowsPerPage = firstPage.length || pageSize;
        const reportedPageCount = hasReportedCount ? Math.max(1, Math.ceil(reportedCount / rowsPerPage)) : null;
        const allOrders = [];
        const uniqueOrders = new Map();
        let page = 1;
        let terminalPage = false;
        let completedPageCount = 0;
        const pageRowCounts = [];
        while (page <= (run.maxListPages || MAX_LIST_PAGES)) {
            if (run.controller.signal.aborted) throw run.controller.signal.reason || new DOMException('核算已取消', 'AbortError');
            const pageData = page === 1 ? firstPage : requireApiList(await apiGetRetry(
                LIST_PATH,
                Object.assign({}, filters, { page, limit: pageSize }),
                run.controller.signal,
                '采购列表第 ' + page + ' 页'
            ), '采购列表第 ' + page + ' 页');
            if (pageData.length === 0) {
                terminalPage = true;
                break;
            }
            pageRowCounts.push(pageData.length);
            let pageAdded = 0;
            pageData.forEach((order) => {
                const id = String(order && order.purchaseOrderId || '').trim();
                if (!id) throw new CostError('采购列表缺少订单 ID', '第 ' + page + ' 页存在没有 purchaseOrderId 的记录。');
                if (!uniqueOrders.has(id)) {
                    uniqueOrders.set(id, order);
                    allOrders.push(order);
                    pageAdded += 1;
                }
            });
            if (page > 1 && pageAdded === 0) {
                throw new CostError('采购列表分页未前进', '第 ' + page + ' 页与上一页返回了相同订单，分页参数可能未生效。');
            }
            if (run.maxOrders && uniqueOrders.size > run.maxOrders) throw new CostError('资料采购历史超过预算', '请缩小采购查询范围后补充资料。');
            completedPageCount = page;
            if (hasReportedCount && uniqueOrders.size >= reportedCount) {
                terminalPage = true;
                setLoading('正在读取采购单', '正在读取订单列表… ' + page + '/' + reportedPageCount + ' 页', 24);
                break;
            }
            page += 1;
            setLoading(
                '正在读取采购单',
                reportedPageCount ? '正在读取订单列表… ' + page + '/' + reportedPageCount + ' 页' : '正在读取订单列表… 第 ' + page + ' 页',
                hasReportedCount ? Math.min(24, 5 + Math.round((uniqueOrders.size / Math.max(reportedCount, 1)) * 19)) : Math.min(24, 5 + page * 2)
            );
        }
        if (!terminalPage) {
            throw new CostError(
                '采购列表分页超过安全上限',
                '已连续读取 ' + (run.maxListPages || MAX_LIST_PAGES) + ' 页仍未结束，请检查 ERP 的分页参数。'
            );
        }
        return {
            orders: allOrders,
            pageCount: completedPageCount,
            reportedCount: hasReportedCount ? reportedCount : null,
            countMismatch: hasReportedCount && uniqueOrders.size !== reportedCount,
            pageSize,
            pageSizeFallback: usedFallback,
            firstPageRowCount: pageRowCounts[0] || 0,
            maxReturnedPerPage: pageRowCounts.length > 0 ? Math.max(...pageRowCounts) : 0,
            pageRowCounts
        };
    }

    async function fetchAllDetails(orders, run) {
        const cancelledStatus = /(?:^|[\s:：])(?:11|cancel(?:led)?|void(?:ed)?|已取消|取消|已作废|作废|已关闭|关闭)(?:$|[\s:：])/i;
        const orderStatusValues = (order) => {
            const values = [
                order && order.purchaseStatus,
                order && order.paymentStatus,
                order && order.payStatus,
                order && order.orderStatus,
                order && order.order1688Status,
                order && order.orderStatus1688,
                order && order.purchaseOrderStatus,
                order && order.status
            ];
            Object.keys(order || {}).forEach((key) => {
                if (/(status|state|状态)/i.test(key)) values.push(order[key]);
            });
            return [...new Set(values.map((value) => String(value || '').normalize('NFKC').trim()).filter(Boolean))];
        };
        const isCancelledOrder = (order) => {
            return orderStatusValues(order).some((normalized) => {
                return normalized === '11' || cancelledStatus.test(normalized);
            });
        };
        const validOrders = orders.filter((order) => !isCancelledOrder(order));
        const excludedOrders = orders.filter(isCancelledOrder).map((order) => ({
            purchaseOrderId: String(order && order.purchaseOrderId || '').trim(),
            purchaseOrderNo: String(order && order.purchaseOrderNo || '').trim(),
            order1688: String(order && order.purchaseOrderNo1688 || '').trim(),
            warehouseSku: String(order && (order.itemId || order.warehouseSku || order.skuCode || order.sku) || '').trim(),
            supplierName: supplierName(order),
            supplier1688Url: resolveSupplier1688Url(null, order),
            statusValues: orderStatusValues(order),
            exclusionReasons: ['cancelled_or_closed']
        }));
        setLoading('正在读取采购明细', '0 / ' + validOrders.length + ' 个订单', 26);
        const failedOrders = [];

        const detailGroups = await mapConcurrent(
            validOrders,
            MAX_CONCURRENT_DETAIL,
            async (order) => {
                const id = String(order.purchaseOrderId || '').trim();
                const cacheKey = 'detail_' + id;
                const cached = getCache(cacheKey);
                if (Array.isArray(cached)) return cached.map((detail) => withOrderContext(detail, order, id));
                try {
                    const response = await apiGetRetry(
                        DETAIL_PATH,
                        { purchaseOrderId: id, supplierId: order.supplierId || '' },
                        run.controller.signal,
                        '采购单 ' + (order.purchaseOrderNo || order.purchaseOrderNo1688 || id) + ' 明细'
                    );
                    const data = requireApiList(response, '采购单 ' + (order.purchaseOrderNo || id) + ' 明细');
                    const normalized = data.map((detail) => withOrderContext(detail, order, id));
                    setCache(cacheKey, normalized);
                    return normalized;
                } catch (error) {
                    if (run.controller.signal.aborted || error.code === 'ERP_LOGIN_REQUIRED') throw error;
                    failedOrders.push({ id, no: order.purchaseOrderNo || order.purchaseOrderNo1688 || id, message: error.message || String(error) });
                    return [];
                }
            },
            run,
            (completed, total) => {
                const progress = 26 + Math.round((completed / Math.max(total, 1)) * 38);
                setLoading('正在读取采购明细', completed + ' / ' + total + ' 个订单', progress);
            }
        );

        return {
            details: detailGroups.flat(),
            validOrderCount: validOrders.length,
            skippedOrderCount: orders.length - validOrders.length,
            skippedCancelledOrderCount: orders.length - validOrders.length,
            excludedOrders,
            failedOrders
        };
    }

    function aggregateDetails(details, { allowEmpty = false } = {}) {
        const buckets = new Map();
        const excludedDetails = [];
        let skippedInvalid = 0;

        details.forEach((detail, detailIndex) => {
            const warehouseSku = String(detail && detail.itemId || '').trim();
            const date = parseDateInfo(detail && detail.creationTime);
            const qty = Number.parseFloat(detail && detail.purchaseQuantity);
            const unitPrice = Number.parseFloat(detail && detail.purchaseUnitPrice);
            const purchaseCatalog = resultPolicy.purchaseCatalogFromDetail(detail);
            const evidenceBase = {
                recordId: String(detail.detailId || detail.purchaseOrderDetailId || detail.id || ((detail._purchaseOrderId || detail.purchaseOrderId || 'order') + ':' + detailIndex)).trim(),
                warehouseSku,
                name: String(detail.tradeName || '').trim(),
                imageUrl: resultPolicy.purchaseImageUrl(detail),
                attribute: resultPolicy.catalogText(detail.attribute),
                ...(purchaseCatalog ? { purchaseCatalog } : {}),
                quantity: Number.isFinite(qty) ? qty : null,
                unitPrice: Number.isFinite(unitPrice) ? unitPrice : null,
                totalPrice: Number.isFinite(qty) && Number.isFinite(unitPrice) ? qty * unitPrice : null,
                purchaseDate: date ? date.text : String(detail && detail.creationTime || '').trim(),
                order1688: String(detail._orderNo1688 || '').trim(),
                purchaseOrderNo: String(detail._purchaseOrderNo || '').trim(),
                purchaseOrderId: String(detail._purchaseOrderId || detail.purchaseOrderId || '').trim(),
                supplierName: String(detail._supplierName || supplierName(detail) || '').trim(),
                supplier1688Url: String(detail._supplier1688Url || resolveSupplier1688Url(detail, null) || '').trim(),
                supplier1688Links: resultPolicy.normalizeSupplier1688Links(detail._supplier1688Links || resolveSupplier1688Links(detail, null)),
                statusFields: {
                    purchaseStatus: detail.purchaseStatus ?? detail._purchaseStatus ?? null,
                    paymentStatus: detail.paymentStatus ?? detail.payStatus ?? detail._paymentStatus ?? null,
                    orderStatus: detail.orderStatus ?? detail._orderStatus ?? null,
                    order1688Status: detail.order1688Status ?? detail.orderStatus1688 ?? detail._order1688Status ?? null
                },
                eligible: false,
                selectedForPreview: false,
                exclusionReasons: []
            };
            if (!warehouseSku || !date || !Number.isFinite(qty) || qty <= 0 || !Number.isFinite(unitPrice) || unitPrice < 0) {
                skippedInvalid += 1;
                excludedDetails.push(Object.assign({}, evidenceBase, { exclusionReasons: ['invalid_purchase_detail'] }));
                return;
            }
            if (!buckets.has(warehouseSku)) buckets.set(warehouseSku, []);
            buckets.get(warehouseSku).push({
                recordId: evidenceBase.recordId,
                warehouseSku,
                name: evidenceBase.name,
                imageUrl: evidenceBase.imageUrl,
                attribute: evidenceBase.attribute,
                ...(purchaseCatalog ? { purchaseCatalog } : {}),
                qty,
                unitPrice,
                totalPrice: qty * unitPrice,
                date: date.text,
                dateValue: date.dateValue,
                timestamp: date.timestamp,
                order1688: evidenceBase.order1688,
                purchaseOrderNo: evidenceBase.purchaseOrderNo,
                purchaseOrderId: evidenceBase.purchaseOrderId,
                supplierName: evidenceBase.supplierName,
                supplier1688Url: evidenceBase.supplier1688Url,
                supplier1688Links: evidenceBase.supplier1688Links,
                statusFields: evidenceBase.statusFields
            });
        });

        if (buckets.size === 0 && !allowEmpty) {
            throw new CostError(
                '没有可用的采购明细',
                '无日期、无 SKU、数量不大于 0 或单价无效的记录不参与预览；账本月末截止范围待工作台筛选。'
            );
        }

        const results = [];
        const warehouses = [];
        buckets.forEach((records, warehouseSku) => {
            records.sort((a, b) => {
                if (a.timestamp !== b.timestamp) return b.timestamp - a.timestamp;
                return b.purchaseOrderId.localeCompare(a.purchaseOrderId, 'zh-CN', { numeric: true });
            });

            const annotatedRecords = resultPolicy.annotateCostWarnings(records);
            const selected = selectCostRecords(annotatedRecords);
            const selectedRecords = new Set(selected);
            const totalQty = selected.reduce((sum, record) => sum + record.qty, 0);
            const totalPrice = selected.reduce((sum, record) => sum + record.totalPrice, 0);
            const newest = selected[0];
            const oldest = selected[selected.length - 1];
            const sourceTypes = new Set(selected.map((record) => record.order1688 ? '1688' : '采购单'));
            const sourceType = sourceTypes.size > 1 ? '混合采购' : [...sourceTypes][0];
            const costWarnings = resultPolicy.summarizeCostWarnings(selected);

            warehouses.push({
                warehouseSku,
                evidenceComplete: true,
                purchaseRecords: annotatedRecords.map((record) => ({
                    recordId: record.recordId,
                    warehouseSku: record.warehouseSku,
                    productName: record.name,
                    imageUrl: record.imageUrl,
                    attribute: record.attribute,
                    ...(Object.hasOwn(record, 'purchaseCatalog') ? { purchaseCatalog: record.purchaseCatalog } : {}),
                    quantity: record.qty,
                    unitPrice: record.unitPrice,
                    totalPrice: record.totalPrice,
                    purchaseDate: record.date,
                    order1688: record.order1688,
                    purchaseOrderNo: record.purchaseOrderNo,
                    purchaseOrderId: record.purchaseOrderId,
                    supplierName: record.supplierName,
                    supplier1688Url: record.supplier1688Url,
                    supplier1688Links: record.supplier1688Links,
                    statusFields: record.statusFields,
                    eligible: true,
                    selectedForPreview: selectedRecords.has(record),
                    exclusionReasons: [],
                    warningReasons: record.warningReasons
                }))
            });

            results.push({
                warehouseSku,
                name: newest.name || records[0].name || '',
                imageUrl: newest.imageUrl || '',
                attribute: newest.attribute || '',
                ...(Object.hasOwn(newest, 'purchaseCatalog') ? { purchaseCatalog: newest.purchaseCatalog } : {}),
                mappings: [],
                catalogMappings: [],
                sourceType,
                orderNumber: newest.order1688 || newest.purchaseOrderNo || '',
                calcTimes: selected.length,
                dateRange: newest.date === oldest.date ? newest.date : oldest.date + ' ~ ' + newest.date,
                totalQty,
                totalPrice: totalPrice.toFixed(2),
                unitCost: (totalPrice / totalQty).toFixed(4),
                proposedUnitCost: (totalPrice / totalQty).toFixed(4),
                latestTimestamp: newest.timestamp,
                supplierName: newest.supplierName || '',
                supplier1688Url: newest.supplier1688Url || '',
                supplier1688Links: resultPolicy.normalizeSupplier1688Links(selected.flatMap(record => record.supplier1688Links || [])),
                selectedRecordIds: [...new Set(selected.map((record) => record.recordId))],
                costWarnings,
                costWarningCount: costWarnings.count,
                details: selected.map((record) => ({
                    recordId: record.recordId,
                    date: record.date,
                    orderNumber: record.order1688 || record.purchaseOrderNo || '',
                    sourceType: record.order1688 ? '1688' : '采购单',
                    qty: record.qty,
                    price: record.totalPrice.toFixed(2),
                    unitPrice: record.unitPrice.toFixed(4),
                    warningReasons: record.warningReasons,
                    supplierName: record.supplierName,
                    supplier1688Url: record.supplier1688Url,
                    supplier1688Links: record.supplier1688Links,
                }))
            });
        });

        results.sort((a, b) => a.warehouseSku.localeCompare(b.warehouseSku, 'zh-CN', { numeric: true }));
        return {
            results,
            skippedInvalid,
            warehouseEvidence: {
                formatVersion: 1,
                warehouses,
                excludedDetails
            }
        };
    }

    async function readWarehouseEvidence(warehouseSku, run) {
        // Only page-captured filters are known to be accepted by this ERP.
        // One bounded scope read is shared by every missing warehouse.
        if (!run.filters) return { warehouseSku, purchaseRecords: [], excludedRecords: [], sourceWarnings: ['captured_purchase_scope_missing'], evidenceComplete: false };
        if (!run.purchaseEvidencePromise) run.purchaseEvidencePromise = (async () => {
            const orders = await fetchAllOrders(run.filters, { ...run, maxListPages: 10, maxOrders: 500 });
            const details = await fetchAllDetails(orders.orders, run);
            return { aggregate: aggregateDetails(details.details, { allowEmpty: true }), orders, details };
        })();
        const { aggregate, orders, details } = await run.purchaseEvidencePromise;
        const matches = item => resultPolicy.canonical(item?.warehouseSku) === resultPolicy.canonical(warehouseSku);
        const existing = aggregate.warehouseEvidence.warehouses.find(matches);
        const sourceWarnings = [...(orders.countMismatch ? ['purchase_count_mismatch'] : []), ...details.failedOrders.map(item => 'detail_failure:' + item.id)];
        return { warehouseSku, purchaseRecords: existing?.purchaseRecords || [], excludedRecords: [...aggregate.warehouseEvidence.excludedDetails, ...details.excludedOrders].filter(matches), sourceWarnings, evidenceComplete: !sourceWarnings.length };
    }

    async function supplementCatalog() {
        if (activeRun || !isPurchasePage() || needsLogin() || !catalogCollector) return;
        const run = { controller: new AbortController(), cancelledByUser: false, filters: capturedListUrl ? parseCapturedFilters() : null };
        activeRun = run;
        renderPageContext();
        hideError();
        try {
            const bridge = window.ShopeersErpDeliveryBridge;
            const context = (await requestContextPolicy.settleRequestContext(bridge.catalogContext({}), 5000)).context;
            if (!context?.ok || !context.request) throw new CostError('资料请求未关联', context?.message || '请先在工作台登记补充资料请求。');
            setLoading('正在补充 ERP 资料', context.request.platformSkcs.join(' / '), 5);
            const state = await catalogCollector.collect(context.request.platformSkcs, run);
            if (run.controller.signal.aborted) return;
            const response = await bridge.submitCatalog({ requestId: context.request.requestId, querySkcs: context.request.platformSkcs, results: state.results, warehouseEvidence: state.warehouseEvidence, catalogCoverage: state.coverage, resultDeliveryId: makeResultDeliveryId(), createdAt: new Date().toISOString() });
            showToast(response?.status === 'success' ? '资料已送达本机收件服务' : response?.retained ? '资料已由扩展后台保留，等待持久收件确认' : '资料尚未确认送达，请重试补充资料', response?.status === 'failed' ? 'error' : undefined);
        } catch (error) {
            if (!run.cancelledByUser) showError(error instanceof CostError ? error : new CostError('补充 ERP 资料失败', error?.message || String(error)));
        } finally {
            if (activeRun === run) activeRun = null;
            hideLoading();
            renderPageContext();
        }
    }

    async function fetchMappings(results, run) {
        if (!catalogCollector) throw new CostError('资料模块未加载', '请重新安装完整 ERP Assistant 扩展。');
        const failedMappings = [];
        await mapConcurrent(results, MAX_CONCURRENT_SKU, async result => {
            const state = await catalogCollector.mappings(result.warehouseSku, run);
            result.mappings = state.mappings;
            result.catalogMappings = state.catalogMappings;
            result.catalogMappingsComplete = state.complete;
            if (!state.complete) failedMappings.push({ warehouseSku: result.warehouseSku, message: state.reasons.join(';') });
        }, run);
        return { failedMappings };
    }

    async function runCalculation(filters, run) {
        const startedAt = Date.now();
        const querySkcs = extractQuerySkcs(filters);
        const previewContext = await readPreviewContext(querySkcs, run.queryCapturedAt);
        const orderState = await fetchAllOrders(filters, run);
        const orders = orderState.orders;
        const detailState = await fetchAllDetails(orders, run);
        setLoading('正在整理采购证据', previewContext.ledgerPeriod ? `台账月份：${previewContext.ledgerPeriod}` : '未取得台账月份，继续采集完整证据', 65);
        const aggregateState = aggregateDetails(detailState.details);
        const mappingState = await fetchMappings(aggregateState.results, run);
        for (const warehouse of aggregateState.warehouseEvidence.warehouses) {
            warehouse.evidenceComplete = !orderState.countMismatch && !detailState.failedOrders.length;
        }
        const catalogState = { coverage: Object.fromEntries(['directory','mappings','images','suppliers','purchaseEvidence'].map(group => [group, { state: 'unavailable', reasons: ['catalog_supplement_pending'] }])) };
        const mappingPartition = resultPolicy.partitionResultsByMapping(aggregateState.results);
        const scopedState = resultPolicy.filterCatalogBySkc(mappingPartition.mapped, querySkcs);
        const resultMappings = scopedState.results.flatMap((item) => item.mappings || []);

        const scopedWarehouseSkus = new Set(scopedState.results.map((result) => resultPolicy.canonical(result.warehouseSku)).filter(Boolean));
        const evidenceOnlySourceRecords = [
            ...detailState.excludedOrders,
            ...aggregateState.warehouseEvidence.excludedDetails,
            ...mappingState.failedMappings,
        ];
        const evidenceOnlyResults = resultPolicy.buildEvidenceOnlyResults({
            unmappedResults: mappingPartition.evidenceOnly,
            sourceRecords: evidenceOnlySourceRecords,
            excludedWarehouseSkus: [...scopedWarehouseSkus],
        });
        const evidenceWarehouseSkus = new Set([
            ...scopedWarehouseSkus,
            ...evidenceOnlyResults.map((item) => resultPolicy.canonical(item.warehouseSku)),
        ]);
        const warehouseEvidence = {
            formatVersion: 1,
            warehouses: [...new Map([...aggregateState.warehouseEvidence.warehouses, ...(catalogState.warehouseEvidence?.warehouses || [])].map(item => [resultPolicy.canonical(item.warehouseSku), item])).values()].filter((item) => evidenceWarehouseSkus.has(resultPolicy.canonical(item.warehouseSku))),
            excludedOrders: detailState.excludedOrders,
            excludedDetails: aggregateState.warehouseEvidence.excludedDetails.filter((item) => (
                !item.warehouseSku || evidenceWarehouseSkus.has(resultPolicy.canonical(item.warehouseSku))
            )),
            detailFailures: detailState.failedOrders,
            mappingFailures: mappingState.failedMappings
        };
        const previewResults = resultPolicy.previewForLedger([...scopedState.results, ...evidenceOnlyResults], warehouseEvidence, previewContext.ledgerPeriod);
        const warningMeta = buildWarningMeta(previewResults);
        for (const warehouse of warehouseEvidence.warehouses) {
            const ids = new Set(previewResults.find(result => resultPolicy.canonical(result.warehouseSku) === resultPolicy.canonical(warehouse.warehouseSku))?.selectedRecordIds || []);
            warehouse.purchaseRecords.forEach(record => { record.selectedForPreview = ids.has(record.recordId); });
        }
        return {
            catalogInitial: aggregateState,
            results: previewResults,
            warehouseEvidence,
            meta: {
                catalogVersion: 1,
                catalogCoverage: catalogState.coverage,
                queryCapturedAt: run.queryCapturedAt,
                registeredBefore: run.queryCapturedAt,
                filters,
                querySkcs,
                mappingScopeApplied: scopedState.scoped,
                excludedMappingCount: scopedState.excludedMappingCount,
                excludedWarehouseSkuCount: scopedState.excludedWarehouseSkuCount,
                orderCount: orders.length,
                orderPageCount: orderState.pageCount,
                pageSize: orderState.pageSize,
                pageSizeFallback: orderState.pageSizeFallback,
                firstPageRowCount: orderState.firstPageRowCount,
                maxReturnedPerPage: orderState.maxReturnedPerPage,
                pageRowCounts: orderState.pageRowCounts,
                reportedOrderCount: orderState.reportedCount,
                orderCountMismatch: orderState.countMismatch,
                validOrderCount: detailState.validOrderCount,
                skippedOrderCount: detailState.skippedOrderCount,
                skippedCancelledOrderCount: detailState.skippedCancelledOrderCount,
                detailCount: detailState.details.length,
                detailFailureCount: detailState.failedOrders.length,
                detailFailures: detailState.failedOrders,
                mappingFailureCount: mappingState.failedMappings.length,
                mappingFailures: mappingState.failedMappings,
                skippedInvalid: aggregateState.skippedInvalid,
                warehouseSkuCount: previewResults.length,
                platformSkuCount: resultMappings.length,
                platformSkcCount: new Set(resultMappings.map((item) => resultPolicy.canonical(item.platformSkc)).filter(Boolean)).size,
                costWarningCount: warningMeta.costWarningCount,
                evidenceRecordCount: warehouseEvidence.warehouses.reduce((sum, item) => sum + item.purchaseRecords.length, 0),
                excludedEvidenceCount: warehouseEvidence.excludedOrders.length + warehouseEvidence.excludedDetails.length,
                exclusionStats: [...warehouseEvidence.excludedOrders, ...warehouseEvidence.excludedDetails].map((record) => ({
                    recordId: record.recordId || null,
                    purchaseOrderId: record.purchaseOrderId || null,
                    purchaseOrderNo: record.purchaseOrderNo || null,
                    order1688: record.order1688 || null,
                    warehouseSku: record.warehouseSku || null,
                    supplierName: record.supplierName || null,
                    supplier1688Url: record.supplier1688Url || null,
                    statusValues: Array.isArray(record.statusValues) ? record.statusValues.join('|') : '',
                    exclusionReasons: Array.isArray(record.exclusionReasons) ? record.exclusionReasons.join('|') : ''
                })),
                sourceFormat: 'erp-assistant-v8-preview-evidence',
                extensionVersion: EXTENSION_VERSION,
                durationMs: Date.now() - startedAt,
                ledgerPeriod: previewContext.ledgerPeriod,
                previewContextMessage: previewContext.message || null,
                previewScope: previewContext.ledgerPeriod ? 'ledger_month' : 'period_unknown',
                ledgerMonthCutoffStatus: previewContext.ledgerPeriod ? 'applied' : 'pending_ledger'
            }
        };
    }

    async function completeOptionalCatalog(state, run) {
        try {
            const bridge = window.ShopeersErpDeliveryBridge;
            const settled = await requestContextPolicy.settleRequestContext(bridge.catalogContext({ querySkcs: state.meta.querySkcs, queryCapturedAt: run.queryCapturedAt }), 5000);
            const context = settled.context;
            if (!context?.ok || !context.request) { showToast('成本已完成；资料请求未关联，可在工作台登记后补充资料'); return; }
            if (run.controller.signal.aborted) return;
            run.catalogPhase = true;
            setLoading('成本已完成，正在补充资料', '资料最多60秒；可取消，成本结果已保留', 70);
            const catalog = await catalogCollector.collect(state.meta.querySkcs, run, state.catalogInitial);
            if (run.controller.signal.aborted) return;
            if (context.request.platformSkcs.length !== state.meta.querySkcs.length) {
                for (const group of Object.values(catalog.coverage)) {
                    if (group.state === 'complete') group.state = 'partial';
                    group.reasons.push('query_scope_subset');
                }
            }
            if (run.controller.signal.aborted) return;
            const response = await bridge.submitCatalog({ requestId: context.request.requestId, querySkcs: context.request.platformSkcs, results: catalog.results, warehouseEvidence: catalog.warehouseEvidence, catalogCoverage: catalog.coverage, resultDeliveryId: makeResultDeliveryId(), createdAt: new Date().toISOString() });
            showToast(response?.status === 'success' ? '资料已送达本机收件服务' : response?.retained ? '资料已由扩展后台保留，等待持久收件确认' : '资料尚未确认送达，请重试补充资料');
        } catch (error) {
            if (!run.cancelledByUser) showToast('成本已完成；资料补充未完成：' + (error.message || String(error)), 'error');
        } finally { hideLoading(); }
    }

    async function calculate() {
        if (activeRun) {
            activeRun.cancelledByUser = true;
            activeRun.controller.abort();
        }

        hideError();
        lastResults = [];
        lastMeta = null;
        lastWarehouseEvidence = null;
        updateActionState();
        renderResults();

        let filters;
        try {
            filters = parseCapturedFilters();
        } catch (error) {
            showError(error);
            return;
        }

        const run = {
            controller: new AbortController(),
            cancelledByUser: false,
            filters,
            queryCapturedAt: capturedQueryCapturedAt || new Date().toISOString()
        };
        activeRun = run;
        setLoading('准备核算', '正在校验采购查询条件', 2);

        try {
            const state = await runCalculation(filters, run);
            if (run.cancelledByUser) return;
            lastImportEnvelope = null;
            lastResults = state.results;
            lastMeta = state.meta;
            lastWarehouseEvidence = state.warehouseEvidence;
            const resultDeliveryId = makeResultDeliveryId();
            const deliveryState = {
                createdAt: new Date().toISOString(),
                queryCapturedAt: run.queryCapturedAt,
                attemptsTotal: 0,
                deliveryTerminal: false
            };
            setResultCache(lastResults, lastMeta, lastWarehouseEvidence, capturedListUrl, resultDeliveryId, deliveryState);
            dispatchCostResults(lastResults, lastMeta, lastWarehouseEvidence, resultDeliveryId, deliveryState);
            expandedRows.clear();
            setLoading('核算完成', '正在生成结果表', 100);
            renderResults();
            renderAnomalyBanner();
            renderStatus();
            updateActionState();
            hideLoading();
            showToast('成本采集完成，共 ' + lastResults.length + ' 个仓库 SKU；送达状态以回传提示为准');
            // Cost cache, dispatch and rendering precede every optional ERP request.
            if (catalogCollector) await completeOptionalCatalog(state, run);
        } catch (error) {
            if (run.cancelledByUser || (error && error.name === 'AbortError')) {
                hideLoading();
                showToast('核算已取消');
            } else {
                console.error(PREFIX, error);
                hideLoading();
                showError(error);
            }
        } finally {
            if (activeRun === run) activeRun = null;
            renderPageContext();
        }
    }

    function escapeHtml(value) {
        return String(value === undefined || value === null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function buildExportRows(results) {
        const rows = [];
        results.forEach((result) => {
            const mappings = result.mappings.length > 0 ? result.mappings : [{ platformSku: '', platformSkc: '' }];
            mappings.forEach((mapping) => {
                rows.push({
                    warehouseSku: result.warehouseSku,
                    platformSku: mapping.platformSku,
                    platformSkc: mapping.platformSkc || '',
                    orderNumber: selectedPreviewValues(result, 'orderNumber', result.orderNumber).join('\n'),
                    sourceType: selectedPreviewValues(result, 'sourceType', result.sourceType).join('\n'),
                    name: result.name,
                    calcTimes: result.calcTimes,
                    purchaseDates: selectedPreviewValues(result, 'date', result.dateRange).join('\n'),
                    totalQty: result.totalQty,
                    totalPrice: result.totalPrice,
                    unitCost: result.unitCost,
                    supplierName: result.supplierName || '',
                    supplier1688Url: result.supplier1688Url || '',
                    costWarningCount: resultCostWarnings(result).count,
                    costWarningReasons: resultCostWarnings(result).reasons.map((reason) => resultPolicy.costWarningLabel(reason)).join('；'),
                    costWarningRecords: resultCostWarnings(result).records
                });
            });
        });
        return rows;
    }

    function csvCell(value) {
        const text = String(value === undefined || value === null ? '' : value);
        // Quote escaping alone does not prevent spreadsheet formulas. Textify only
        // the exported value, preserving numeric cells and the raw evidence/cache.
        const safeText = typeof value !== 'number' && /^\s*[=+\-@＝＋－＠\u0000-\u001f\u007f]/.test(text)
            ? "'" + text
            : text;
        return '"' + safeText.replace(/"/g, '""') + '"';
    }

    async function copyTextWithFallback(text) {
        let clipboardError = null;
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            try {
                await navigator.clipboard.writeText(text);
                return;
            } catch (error) {
                clipboardError = error;
            }
        }

        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.setAttribute('readonly', '');
        textarea.setAttribute('aria-hidden', 'true');
        textarea.style.position = 'fixed';
        textarea.style.top = '0';
        textarea.style.left = '-9999px';
        textarea.style.width = '1px';
        textarea.style.height = '1px';
        textarea.style.opacity = '0';
        textarea.style.pointerEvents = 'none';
        document.body.appendChild(textarea);
        try {
            textarea.focus({ preventScroll: true });
            textarea.select();
            textarea.setSelectionRange(0, textarea.value.length);
            if (!document.execCommand('copy')) {
                throw clipboardError || new Error('document.execCommand(copy) returned false');
            }
        } finally {
            textarea.remove();
        }
    }

    async function copyCosts() {
        if (lastResults.length === 0) return;
        const lines = ['平台SKU\t平台SKC\t仓库SKU\t所选采购单号\t预览单件成本\t供应商1688链接\t疑似异常\t提示原因\t原始提示JSON\t所选采购日期\t所选单号类型\t预览范围'];
        buildExportRows(lastResults).forEach((row) => {
            lines.push([row.platformSku, row.platformSkc, row.warehouseSku, row.orderNumber.replace(/\n/g, '；'), row.unitCost, row.supplier1688Url, row.costWarningCount, row.costWarningReasons, JSON.stringify(row.costWarningRecords), row.purchaseDates.replace(/\n/g, '；'), row.sourceType.replace(/\n/g, '；'), previewScopeLabel()].join('\t'));
        });
        try {
            await copyTextWithFallback(lastImportEnvelope ? JSON.stringify(lastImportEnvelope, null, 2) : lines.join('\n'));
            showToast(lastImportEnvelope ? '已复制完整证据 JSON，可导入工作台' : '已复制兼容表格预览；尚无已接收证据，不能直接作 ERP 正式成本');
        } catch (error) {
            showError(new CostError('复制失败', '当前页面未允许剪贴板写入，请重试或检查浏览器权限。'));
        }
    }

    function exportCsv() {
        if (lastResults.length === 0) return;
        const headers = [
            '仓库SKU', '平台SKU', '平台SKC', '所选单号类型', '所选采购单号', '产品名称', '供应商', '供应商1688链接', '疑似异常', '提示原因', '原始提示JSON',
            '预览次数', '所选采购日期', '总采购量', '总采购价(￥)', '预览单件成本', '预览范围'
        ];
        const lines = [headers.map(csvCell).join(',')];
        buildExportRows(lastResults).forEach((row) => {
            lines.push([
                row.warehouseSku, row.platformSku, row.platformSkc, row.sourceType, row.orderNumber, row.name, row.supplierName, row.supplier1688Url, row.costWarningCount, row.costWarningReasons, JSON.stringify(row.costWarningRecords),
                row.calcTimes, row.purchaseDates, row.totalQty, row.totalPrice, row.unitCost, previewScopeLabel()
            ].map(csvCell).join(','));
        });
        const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'SKU成本核算_' + (resultPolicy.validLedgerPeriod(lastMeta?.ledgerPeriod) || '月份待关联') + '.csv';
        link.click();
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        showToast('已导出 ' + (lines.length - 1) + ' 条成本数据');
    }

    function getFilteredResults() {
        const words = searchText.trim().toLowerCase().split(/\s+/).filter(Boolean);
        if (words.length === 0) return lastResults;
        return lastResults.filter((result) => {
            const mappings = result.mappings.map((mapping) => [mapping.platformSku, mapping.platformSkc].filter(Boolean).join(' ')).join(' ');
            const haystack = [
                result.warehouseSku, result.name, result.orderNumber, result.sourceType, result.supplierName, result.supplier1688Url, mappings,
                ...(result.details || []).map((detail) => [detail.date, detail.sourceType, detail.orderNumber].join(' '))
            ].join(' ').toLowerCase();
            return words.every((word) => haystack.includes(word));
        });
    }

    function renderPlatformCell(result) {
        if (result.mappings.length === 0) {
            return '<span class="erpa-muted">未映射（仅保留仓库 SKU 证据）</span>';
        }
        const firstMapping = result.mappings[0];
        const first = escapeHtml(firstMapping.platformSku) + '<br><span class="erpa-platform-skc">' + escapeHtml(firstMapping.platformSkc) + '</span>';
        const extra = result.mappings.length - 1;
        return first + (extra > 0 ? '<span class="erpa-platform-more">+' + extra + '</span>' : '');
    }

    function renderMappingList(result) {
        if (result.mappings.length === 0) return '';
        const visible = result.mappings.slice(0, 120).map((mapping) => (
            escapeHtml(mapping.platformSku) + ' <span class="erpa-platform-skc">· ' + escapeHtml(mapping.platformSkc) + '</span>'
        )).join(' &nbsp; ');
        const remainder = result.mappings.length - 120;
        return '<div style="margin-bottom:10px;color:#5f6d80;line-height:1.7;word-break:break-all;">' +
            '<strong>平台映射（SKU · SKC）：</strong>' + visible + (remainder > 0 ? ' · 其余 ' + remainder + ' 条请查看导出文件' : '') + '</div>';
    }

    function renderSupplier1688Link(url) {
        const normalized = resultPolicy.canonical1688Url(url);
        if (!normalized) return '<span class="erpa-muted">-</span>';
        return '<a class="erpa-offer-link" href="' + escapeHtml(normalized) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(normalized) + '</a>';
    }

    function renderDetail(result) {
        if (result.previewStatus && result.previewStatus !== 'ready') return '<tr class="erpa-detail-row"><td colspan="9"><div class="erpa-detail-wrap">' + renderMappingList(result) + escapeHtml(previewRowStatus(result)) + '</div></td></tr>';
        const rows = result.details.map((detail) => {
            const reasons = warningReasons(detail);
            const hasWarning = reasons.length > 0;
            const warningState = hasWarning
                ? '<span class="erpa-anomaly-badge erpa-anomaly-pending">疑似异常</span><small class="erpa-anomaly-note">' + escapeHtml(formatWarningReasons(reasons)) + '，请在 Lworkstation 利润核算中处理</small>'
                : '<span class="erpa-muted">正常</span>';
            return '<tr class="' + (hasWarning ? 'erpa-detail-anomaly' : '') + '"><td>' + escapeHtml(detail.date) + '</td>' +
            '<td>' + escapeHtml(detail.sourceType) + '</td>' +
            '<td class="erpa-cell-order">' + escapeHtml(detail.orderNumber || '-') + '</td>' +
            '<td class="erpa-cell-number">' + escapeHtml(detail.qty) + '</td>' +
            '<td class="erpa-cell-number">' + escapeHtml(detail.price) + '</td>' +
            '<td class="erpa-cell-number erpa-cell-cost">' + escapeHtml(detail.unitPrice) + '</td>' +
            '<td class="erpa-anomaly-cell">' + warningState + '</td>' +
            '<td>' + renderSupplier1688Link(detail.supplier1688Url) + '</td></tr>';
        }).join('');
        return '<tr class="erpa-detail-row"><td colspan="9"><div class="erpa-detail-wrap">' +
            renderMappingList(result) +
            '<table class="erpa-detail-table"><thead><tr><th>采购日期</th><th>单号类型</th><th>单号</th>' +
            '<th>数量</th><th>总价(￥)</th><th>单价(￥)</th><th>成本状态</th><th>供应商1688链接</th></tr></thead><tbody>' + rows +
            '<tr class="erpa-detail-summary"><td>数量加权平均</td><td></td><td></td>' +
            '<td class="erpa-cell-number">' + escapeHtml(result.totalQty) + '</td>' +
            '<td class="erpa-cell-number">' + escapeHtml(result.totalPrice) + '</td>' +
            '<td class="erpa-cell-number erpa-cell-cost">' + escapeHtml(result.unitCost) + '</td>' +
            '<td><span class="erpa-anomaly-badge erpa-anomaly-confirmed">预览成本</span></td>' +
            '<td>' + renderSupplier1688Link(result.supplier1688Url) + '</td></tr>' +
            '</tbody></table></div></td></tr>';
    }

    function selectedPreviewValues(result, field, fallback) {
        return result.details && result.details.length > 0
            ? result.details.map((detail) => detail[field] || '-')
            : [fallback || ''];
    }

    function renderSelectedOrders(result) {
        const details = result.details && result.details.length > 0
            ? result.details
            : [{ sourceType: result.sourceType, orderNumber: result.orderNumber }];
        return details.map((detail) => '<div>' + escapeHtml(detail.sourceType) + ' · ' + escapeHtml(detail.orderNumber || '-') + '</div>').join('');
    }

    function previewRowStatus(result) {
        return result.previewStatus === 'period_unknown' ? '台账月份待关联' : result.previewStatus === 'no_purchase' ? '台账当月及以前无可用采购' : result.previewStatus === 'evidence_missing' ? '采购证据待补充' : '按台账预览';
    }

    function renderResults() {
        const body = document.getElementById('erpa-table-body');
        const empty = document.getElementById('erpa-empty');
        const tableWrap = document.getElementById('erpa-table-wrap');
        if (!body || !empty || !tableWrap) return;

        const results = getFilteredResults();
        if (results.length === 0) {
            body.innerHTML = '';
            tableWrap.style.display = 'none';
            empty.style.display = 'grid';
            empty.textContent = lastResults.length === 0 ? '暂无核算结果' : '没有匹配的结果';
            return;
        }

        empty.style.display = 'none';
        tableWrap.style.display = 'block';
        body.innerHTML = results.map((result) => {
            const key = result.warehouseSku;
            const expanded = expandedRows.has(key);
            const warnings = resultCostWarnings(result);
            const warningClass = warnings.count > 0 ? ' erpa-result-anomaly' : '';
            const costState = result.previewStatus && result.previewStatus !== 'ready'
                ? '<span class="erpa-anomaly-note">' + escapeHtml(previewRowStatus(result)) + '</span>' : warnings.count > 0
                ? '<span class="erpa-anomaly-badge erpa-anomaly-pending">提示 ' + warnings.count + '</span>'
                : '<span class="erpa-anomaly-badge erpa-anomaly-confirmed">预览</span>';
            const row = '<tr class="erpa-result-row' + (expanded ? ' erpa-expanded' : '') + warningClass + '" data-sku="' + escapeHtml(key) + '">' +
                '<td class="erpa-cell-sku" title="' + escapeHtml(key) + '">' + escapeHtml(key) + '</td>' +
                '<td class="erpa-cell-platform" title="' + escapeHtml(result.mappings.map((item) => item.platformSku + ' · ' + item.platformSkc).join(', ')) + '">' + renderPlatformCell(result) + '</td>' +
                '<td class="erpa-cell-order erpa-selected-records">' + renderSelectedOrders(result) + '</td>' +
                '<td title="' + escapeHtml(result.name) + '">' + escapeHtml(result.name || '-') + '</td>' +
                '<td class="erpa-cell-number">' + result.calcTimes + '</td>' +
                '<td class="erpa-selected-records">' + selectedPreviewValues(result, 'date', result.dateRange).map((date) => '<div>' + escapeHtml(date) + '</div>').join('') + '</td>' +
                '<td class="erpa-cell-number">' + escapeHtml(result.totalQty) + '</td>' +
                '<td class="erpa-cell-number">' + escapeHtml(result.totalPrice) + '</td>' +
                '<td class="erpa-cell-number erpa-cell-cost"><span>' + escapeHtml(result.unitCost ?? '—') + '</span>' + costState + '</td></tr>';
            return row + (expanded ? renderDetail(result) : '');
        }).join('');
    }

    function splitFilterValues(value) {
        return String(value || '')
            .split(/[\s,，;；、]+/)
            .map((item) => item.trim())
            .filter(Boolean);
    }

    function extractQuerySkcs(filters) {
        const source = filters && typeof filters === 'object' ? filters : {};
        const keys = ['sku', 'skc', 'platformSkc', 'platformSKC', 'platformSku', 'platformSKU'];
        for (const key of keys) {
            const values = splitFilterValues(source[key]);
            if (values.length > 0) return values;
        }
        return [];
    }

    function summarizeFilters(filters) {
        const parts = [];
        const candidates = [
            ['sku', 'SKU'], ['orderNo', '单号'], ['storeId', '店铺'],
            ['createTimePeriod', '时间'], ['purchaseStatus', '状态']
        ];
        candidates.forEach(([key, label]) => {
            if (!filters[key]) return;
            if (key === 'sku') {
                const values = splitFilterValues(filters[key]);
                if (values.length > 1) {
                    const preview = values.slice(0, 2).join('、');
                    parts.push(label + '：已选 ' + values.length + ' 个' + (preview ? '（' + preview + (values.length > 2 ? '…' : '') + '）' : ''));
                    return;
                }
            }
            parts.push(label + '：' + String(filters[key]).slice(0, 80) + (String(filters[key]).length > 80 ? '…' : ''));
        });
        return parts.length > 0 ? parts.join('  ·  ') : '当前采购查询未设置额外条件';
    }

    function renderStatus() {
        renderPageContext();
        const scope = document.getElementById('erpa-preview-scope');
        if (scope) scope.textContent = previewScopeLabel() + (lastMeta?.previewContextMessage ? ' · ' + lastMeta.previewContextMessage : ' · 按时间最近三笔，数量加权');
        const status = document.getElementById('erpa-statusbar');
        const footerLeft = document.getElementById('erpa-footer-left');
        const footerRight = document.getElementById('erpa-footer-right');
        if (!status || !footerLeft || !footerRight) return;
        if (!lastMeta) {
            updateIdleStatus();
            footerLeft.textContent = '数据链路：采购列表 → 采购明细 → 平台 SKU/SKC 映射';
            footerRight.textContent = '严格完整性校验';
            return;
        }
        const incomplete = lastMeta.detailFailureCount > 0 || lastMeta.mappingFailureCount > 0;
        status.innerHTML =
            '<span class="erpa-status-item ' + (incomplete ? 'erpa-status-warn' : 'erpa-status-ok') + '"><strong>' +
            (incomplete ? '已完成，但结果可能不完整' : '完整性校验通过') +
            '</strong></span>' +
            '<span class="erpa-status-separator"></span>' +
            '<span class="erpa-status-item">仓库 SKU <strong>' + lastMeta.warehouseSkuCount + '</strong></span>' +
            '<span class="erpa-status-item">平台映射 <strong>' + lastMeta.platformSkuCount + '</strong></span>' +
            (lastMeta.mappingScopeApplied ? '<span class="erpa-status-item">精确范围 <strong>' + lastMeta.platformSkcCount + ' 个 SKC</strong></span>' : '') +
            '<span class="erpa-status-item">有效采购单 <strong>' + lastMeta.validOrderCount + '</strong></span>' +
            '<span class="erpa-status-item">明细 <strong>' + lastMeta.detailCount + '</strong></span>' +
            (lastMeta.skippedOrderCount ? '<span class="erpa-status-item erpa-status-warn">已排除作废单 <strong>' + lastMeta.skippedOrderCount + '</strong></span>' : '') +
            (lastMeta.detailFailureCount ? '<span class="erpa-status-item erpa-status-warn">明细读取失败 <strong>' + lastMeta.detailFailureCount + '</strong></span>' : '') +
            (lastMeta.mappingFailureCount ? '<span class="erpa-status-item erpa-status-warn">平台映射失败 <strong>' + lastMeta.mappingFailureCount + '</strong></span>' : '') +
            (lastMeta.requestContextError ? '<span class="erpa-status-item erpa-status-warn">自动回传上下文异常，本地结果已保留</span>' : '') +
            (lastMeta.excludedMappingCount ? '<span class="erpa-status-item">已排除范围外映射 <strong>' + lastMeta.excludedMappingCount + '</strong></span>' : '') +
            (lastMeta.excludedWarehouseSkuCount ? '<span class="erpa-status-item">未命中仓库SKU <strong>' + lastMeta.excludedWarehouseSkuCount + '</strong></span>' : '') +
            (lastMeta.costWarningCount ? '<span class="erpa-status-item erpa-status-danger">疑似成本异常 <strong>' + lastMeta.costWarningCount + '</strong></span>' : '') +
            '<span class="erpa-status-item">有效采购证据 <strong>' + (lastMeta.evidenceRecordCount || 0) + '</strong></span>' +
            '<span class="erpa-status-item">请求分页 <strong>' + (lastMeta.pageSize || PREFERRED_PAGE_SIZE) + ' 条/页</strong>' + (lastMeta.pageSizeFallback ? '（已回退）' : '') + '</span>' +
            '<span class="erpa-status-item">后台实际返回峰值 <strong>' + (lastMeta.maxReturnedPerPage || 0) + ' 条/页</strong></span>' +
            ((lastMeta.pageSize === PREFERRED_PAGE_SIZE && lastMeta.maxReturnedPerPage > 0 && lastMeta.maxReturnedPerPage < PREFERRED_PAGE_SIZE && lastMeta.reportedOrderCount && lastMeta.reportedOrderCount > lastMeta.maxReturnedPerPage)
                ? '<span class="erpa-status-item erpa-status-warn">ERP 可能将每页限制为 ' + lastMeta.maxReturnedPerPage + ' 条，速度受服务端分页上限影响</span>'
                : '') +
            (lastMeta.orderCountMismatch ? '<span class="erpa-status-item erpa-status-warn">ERP 总数参考值与实际页数据不同，已按分页结果完成读取</span>' : '');
        footerLeft.innerHTML = '筛选：<strong>' + escapeHtml(summarizeFilters(lastMeta.filters)) + '</strong>';
        footerRight.textContent = previewScopeLabel() + ' · 不分单号类型 · 按时间最近' + MAX_RECORDS + '条加权 · ' + (lastMeta.durationMs / 1000).toFixed(1) + '秒' + (lastMeta.cacheRestored ? ' · 临时缓存恢复' : '');
    }

    function updateIdleStatus() {
        const status = document.getElementById('erpa-statusbar');
        if (!status || lastMeta) return;
        status.innerHTML = capturedListUrl ?
            '<span class="erpa-status-item erpa-status-ok"><strong>已捕获最近一次采购查询条件</strong></span>' :
            '<span class="erpa-status-item erpa-status-warn"><strong>等待采购页面查询</strong></span>';
    }

    function setLoading(title, meta, progress) {
        if (activeRun?.catalogPhase) {
            const status = document.getElementById('erpa-catalog-progress');
            if (status) { status.hidden = false; document.getElementById('erpa-catalog-message').textContent = title + ' · ' + meta; }
            return;
        }
        const loading = document.getElementById('erpa-loading');
        if (!loading) return;
        loading.classList.add('erpa-visible');
        document.getElementById('erpa-loading-title').textContent = title;
        document.getElementById('erpa-loading-meta').textContent = meta;
        document.getElementById('erpa-progress-bar').style.width = Math.max(2, Math.min(100, progress)) + '%';
    }

    function hideLoading() {
        const catalog = document.getElementById('erpa-catalog-progress');
        if (catalog) catalog.hidden = true;
        const loading = document.getElementById('erpa-loading');
        if (loading) loading.classList.remove('erpa-visible');
    }

    function showError(error) {
        const panel = document.getElementById('erpa-error');
        if (!panel) return;
        panel.classList.add('erpa-visible');
        document.getElementById('erpa-error-title').textContent = error && error.message ? error.message : '核算失败';
        document.getElementById('erpa-error-message').textContent = error && error.details ? error.details : '';
    }

    function hideError() {
        const panel = document.getElementById('erpa-error');
        if (panel) panel.classList.remove('erpa-visible');
    }

    function showToast(message, type) {
        const panel = document.querySelector('#erpa-cost-root .erpa-panel');
        if (!panel) return;
        const existing = document.getElementById('erpa-toast');
        if (existing) existing.remove();
        const toast = document.createElement('div');
        toast.id = 'erpa-toast';
        toast.className = 'erpa-toast' + (type === 'error' ? ' erpa-toast-error' : '');
        toast.textContent = message;
        panel.appendChild(toast);
        window.clearTimeout(toastTimer);
        toastTimer = window.setTimeout(() => toast.remove(), 2600);
    }

    function renderAnomalyBanner() {
        const banner = document.getElementById('erpa-anomaly-banner');
        if (!banner) return;
        const warningCount = lastResults.reduce((sum, result) => sum + Number(resultCostWarnings(result).count || 0), 0);
        if (warningCount === 0) {
            banner.className = 'erpa-anomaly-banner';
            banner.innerHTML = '';
            return;
        }
        banner.className = 'erpa-anomaly-banner erpa-visible';
        banner.innerHTML = '<span class="erpa-anomaly-copy"><strong>发现 ' + warningCount + ' 条疑似成本异常</strong>' +
            '<small>扩展提供预览并回传原始证据。接收成功后可复制完整 JSON；表格和 CSV 仅作预览。修正与正式发布请在 Lworkstation 成本核对页处理。</small></span>';
    }

    function updateActionState() {
        const disabled = lastResults.length === 0;
        const copy = document.getElementById('erpa-copy');
        const csv = document.getElementById('erpa-export');
        if (copy) copy.disabled = disabled;
        if (csv) csv.disabled = disabled;
    }

    function openPanel() {
        const frame = activePurchaseFrame();
        if (frame) {
            closePanel();
            let origin;
            try { origin = new URL(frame.contentWindow.location.href).origin; } catch { origin = new URL(frame.src).origin; }
            frame.contentWindow.postMessage({ type: 'shopeers.erp.openCostPreview' }, origin);
            return;
        }
        const root = document.getElementById('erpa-cost-root');
        if (!root) return;
        root.classList.add('erpa-open');
        renderAnomalyBanner();
        renderStatus();
        if (isPurchasePage() && !needsLogin() && capturedListUrl && lastResults.length === 0 && !activeRun) calculate();
    }

    function requestRecalculate() {
        if (activeRun || !isPurchasePage() || needsLogin() || !capturedListUrl) return;
        if (lastResults.length > 0 && !window.confirm('重新核算将重新读取 ERP 采购列表、明细和平台 SKU 映射，可能需要较长时间。确定继续吗？')) return;
        calculate();
    }

    function closePanel() {
        const root = document.getElementById('erpa-cost-root');
        if (root) root.classList.remove('erpa-open');
    }

    function createUi() {
        if (!document.body || (!isTopFrame && !isPurchasePage())) return false;

        const existingTrigger = document.getElementById('erpa-cost-trigger');
        const existingRoot = document.getElementById('erpa-cost-root');
        if ((existingTrigger || !isTopFrame) && existingRoot) return true;
        if (existingTrigger) existingTrigger.remove();
        if (existingRoot) existingRoot.remove();

        const trigger = document.createElement('button');
        trigger.id = 'erpa-cost-trigger';
        trigger.type = 'button';
        trigger.innerHTML = '<span class="erpa-trigger-icon" aria-hidden="true">▦</span><span>ERP 成本助手</span>';
        trigger.addEventListener('click', openPanel);

        const root = document.createElement('div');
        root.id = 'erpa-cost-root';
        root.innerHTML =
            '<section class="erpa-panel" role="dialog" aria-modal="true" aria-label="SKU 采购成本预览">' +
                '<header class="erpa-header"><div class="erpa-title-wrap">' +
                    '<div class="erpa-title-line"><h2 class="erpa-title">SKU 采购成本预览</h2><span class="erpa-badge">API v8.0</span></div>' +
                    '<p class="erpa-subtitle" id="erpa-preview-scope">按台账当月及以前采购，取时间最近三笔；完整证据回传工作台</p></div>' +
                    '<button class="erpa-icon-button" id="erpa-close" type="button" title="关闭" aria-label="关闭">×</button></header>' +
                '<div class="erpa-page-context" id="erpa-page-context" role="status" aria-live="polite"></div>' +
                '<div class="erpa-anomaly-banner" id="erpa-anomaly-banner" role="alert"></div>' +
                '<div class="erpa-toolbar">' +
                    '<input class="erpa-search" id="erpa-search" type="search" autocomplete="off" placeholder="搜索仓库 SKU、平台 SKU/SKC、产品名称或单号">' +
                    '<button class="erpa-button erpa-button-primary" id="erpa-recalculate" type="button"><b aria-hidden="true">↻</b><span>重新核算</span></button>' +
                    '<button class="erpa-button" id="erpa-supplement-catalog" type="button"><span>补充资料</span></button>' +
                    '<button class="erpa-button" id="erpa-copy" type="button"><b aria-hidden="true">⎘</b><span>复制成本</span></button>' +
                    '<button class="erpa-button" id="erpa-retry-delivery" type="button"><span>重试回传</span></button>' +
                    '<button class="erpa-button" id="erpa-export" type="button"><b aria-hidden="true">⇩</b><span>导出 CSV</span></button></div>' +
                '<div class="erpa-status-region"><div class="erpa-catalog-progress" id="erpa-catalog-progress" hidden><span id="erpa-catalog-message" role="status" aria-live="polite"></span><button class="erpa-button" id="erpa-cancel-catalog" type="button">取消补充</button></div>' +
                '<div class="erpa-statusbar" id="erpa-statusbar"></div></div>' +
                '<div class="erpa-table-wrap" id="erpa-table-wrap"><table class="erpa-table">' +
                    '<colgroup><col style="width:180px"><col style="width:175px"><col style="width:180px"><col style="width:220px">' +
                    '<col style="width:70px"><col style="width:150px"><col style="width:90px"><col style="width:105px"><col style="width:115px"></colgroup>' +
                    '<thead><tr><th>仓库 SKU</th><th>平台 SKU / SKC</th><th>所选类型 / 采购单号</th><th>产品名称</th>' +
                    '<th>次数</th><th>所选采购日期</th><th>采购量</th><th>采购价(￥)</th><th>预览成本(￥)</th></tr></thead>' +
                    '<tbody id="erpa-table-body"></tbody></table></div>' +
                '<div class="erpa-empty" id="erpa-empty">暂无核算结果</div>' +
                '<footer class="erpa-footer"><span id="erpa-footer-left"></span><span id="erpa-footer-right"></span></footer>' +
                '<div class="erpa-loading" id="erpa-loading"><div class="erpa-loading-box"><div class="erpa-spinner"></div>' +
                    '<p class="erpa-loading-title" id="erpa-loading-title"></p><p class="erpa-loading-meta" id="erpa-loading-meta"></p>' +
                    '<div class="erpa-progress-track"><div class="erpa-progress-bar" id="erpa-progress-bar"></div></div>' +
                    '<button class="erpa-button erpa-button-danger" id="erpa-cancel" type="button">取消核算</button></div></div>' +
                '<div class="erpa-error" id="erpa-error"><div class="erpa-error-box"><h3 class="erpa-error-title" id="erpa-error-title"></h3>' +
                    '<p class="erpa-error-message" id="erpa-error-message"></p><div class="erpa-error-actions">' +
                    '<button class="erpa-button" id="erpa-error-close" type="button">关闭</button>' +
                    '<button class="erpa-button erpa-button-primary" id="erpa-error-retry" type="button">重试</button></div></div></div>' +
            '</section>';

        if (isTopFrame) document.body.appendChild(trigger);
        document.body.appendChild(root);

        const cachedResult = getResultCache();
        if (cachedResult) {
            lastImportEnvelope = cachedResult.importEnvelope || null;
            lastResults = resultPolicy.previewForLedger(cachedResult.results, cachedResult.warehouseEvidence, null);
            lastMeta = Object.assign({}, cachedResult.meta, buildWarningMeta(lastResults), { cacheRestored: true, ledgerPeriod: null });
            lastWarehouseEvidence = cachedResult.warehouseEvidence || null;
            const restoredSnapshot = requestContextPolicy.mergeQuerySnapshot(
                { capturedUrl: capturedListUrl, queryCapturedAt: capturedQueryCapturedAt },
                querySnapshotRestoreAllowed ? {
                    capturedUrl: cachedResult.capturedUrl,
                    queryCapturedAt: cachedResult.queryCapturedAt || cachedResult.meta?.queryCapturedAt,
                    registeredBefore: cachedResult.registeredBefore
                } : {}
            );
            capturedListUrl = restoredSnapshot.capturedUrl;
            capturedQueryCapturedAt = restoredSnapshot.queryCapturedAt;
            const resultDeliveryId = String(cachedResult.resultDeliveryId || '').trim() || makeResultDeliveryId();
            if (!cachedResult.resultDeliveryId) {
                setResultCache(lastResults, lastMeta, lastWarehouseEvidence, capturedListUrl, resultDeliveryId, cachedResult);
            }
            // Delivery retries are owned by extension background storage. Page-origin cache is preview-only.
            if (isPurchasePage()) void restorePreviewContext(cachedResult);
        }

        document.getElementById('erpa-close').addEventListener('click', closePanel);
        document.getElementById('erpa-recalculate').addEventListener('click', requestRecalculate);
        document.getElementById('erpa-supplement-catalog').addEventListener('click', supplementCatalog);
        document.getElementById('erpa-copy').addEventListener('click', copyCosts);
        document.getElementById('erpa-retry-delivery').addEventListener('click', async () => {
            const cached = getResultCache();
            if (!cached?.resultDeliveryId) { showToast('请先采集成本证据'); return; }
            try { handleDeliveryStatus(await window.ShopeersErpDeliveryBridge.retry(cached.resultDeliveryId)); }
            catch (error) { showToast(error.message || '回传重试失败', 'error'); }
        });
        document.getElementById('erpa-export').addEventListener('click', exportCsv);
        document.getElementById('erpa-cancel-catalog').addEventListener('click', () => { if (activeRun) { activeRun.cancelledByUser = true; activeRun.controller.abort(); } });
        document.getElementById('erpa-cancel').addEventListener('click', () => {
            if (activeRun) {
                activeRun.cancelledByUser = true;
                activeRun.controller.abort();
            }
        });
        document.getElementById('erpa-error-close').addEventListener('click', hideError);
        document.getElementById('erpa-error-retry').addEventListener('click', requestRecalculate);
        document.getElementById('erpa-search').addEventListener('input', (event) => {
            searchText = event.target.value;
            renderResults();
        });
        document.getElementById('erpa-table-body').addEventListener('click', (event) => {
            const row = event.target.closest('.erpa-result-row');
            if (!row) return;
            const sku = row.getAttribute('data-sku');
            if (expandedRows.has(sku)) expandedRows.delete(sku);
            else expandedRows.add(sku);
            renderResults();
        });
        root.addEventListener('click', (event) => {
            if (event.target === root) closePanel();
        });
        if (!documentEventsBound) {
            document.addEventListener('keydown', (event) => {
                if (event.key === 'Escape' && !activeRun) closePanel();
            });
            documentEventsBound = true;
        }

        updateActionState();
        renderAnomalyBanner();
        renderStatus();
        renderResults();
        return true;
    }

    function scheduleUiRepair() {
        if (!isTopFrame && !isPurchasePage()) return;
        if ((!isTopFrame || document.getElementById('erpa-cost-trigger')) && document.getElementById('erpa-cost-root')) return;
        window.clearTimeout(uiRepairTimer);
        uiRepairTimer = window.setTimeout(() => {
            uiRepairTimer = null;
            if (createUi()) schedulePageSizeUpgrade();
        }, 0);
    }

    function watchUiIntegrity() {
        if (uiRepairObserver || !document.documentElement || !window.MutationObserver) return;
        uiRepairObserver = new MutationObserver(scheduleUiRepair);
        uiRepairObserver.observe(document.documentElement, { childList: true, subtree: true });
    }

    function initWhenReady() {
        if (document.body) {
            createUi();
            schedulePageSizeUpgrade();
            watchUiIntegrity();
            void reportExtensionStatus();
            return;
        }
        document.addEventListener('DOMContentLoaded', () => {
            createUi();
            schedulePageSizeUpgrade();
            watchUiIntegrity();
            void reportExtensionStatus();
        }, { once: true });
    }

    async function reportExtensionStatus() {
        if (!isTopFrame && !isPurchasePage()) return;
        if (statusReportPending) { statusReportQueued = true; return; }
        const bridge = window.ShopeersErpDeliveryBridge;
        if (!bridge || typeof bridge.reportStatus !== 'function') return;
        statusReportPending = true;
        try {
            const loginRequired = needsLogin();
            const response = await bridge.reportStatus({
                ready: true,
                sessionState: loginRequired ? 'login_required' : erpSessionState,
                pageState: loginRequired ? 'login_required' : isPurchasePage() ? (capturedListUrl ? 'query_ready' : 'purchase_ready') : 'page_ready',
                queryAvailable: !loginRequired && isPurchasePage() && Boolean(capturedListUrl),
                userAgent: navigator.userAgent,
            });
            bridgeConnection = response?.ok ? 'connected' : 'disconnected';
        } catch { bridgeConnection = 'disconnected'; }
        finally {
            statusReportPending = false;
            renderPageContext();
            if (statusReportQueued) {
                statusReportQueued = false;
                void reportExtensionStatus();
            }
        }
    }

    function handleRouteChange() {
        const changed = currentPageUrl !== window.location.href;
        currentPageUrl = window.location.href;
        if (changed) {
            querySnapshotRestoreAllowed = false;
            capturedListUrl = '';
            capturedQueryCapturedAt = '';
            if (activeRun) {
                activeRun.cancelledByUser = true;
                activeRun.controller.abort();
            }
            if (pageSizeObserver) pageSizeObserver.disconnect();
            pageSizeObserver = null;
            pageSizeObservedBody = null;
        }
        if (!isTopFrame && !isPurchasePage()) closePanel();
        createUi();
        renderPageContext();
        updateIdleStatus();
        schedulePageSizeUpgrade();
        void reportExtensionStatus();
    }

    window.addEventListener('shopeers:erp-v8-route-changed', handleRouteChange);
    window.addEventListener('pageshow', handleRouteChange);
    window.addEventListener('online', () => { void reportExtensionStatus(); });
    window.addEventListener('shopeers:erp-v8-session-observed', (event) => {
        if (!['authenticated', 'login_required'].includes(event.detail?.state)) return;
        erpSessionState = event.detail.state;
        if (!isTopFrame) {
            try { window.top.postMessage({ type: 'shopeers.erp.sessionState', state: erpSessionState }, new URL(window.top.location.href).origin); } catch { /* unsupported parent origins receive no signal */ }
        }
        renderPageContext();
        void reportExtensionStatus();
    });
    window.addEventListener('message', (event) => {
        if (isTopFrame && supportedErpUrl(event.origin) && event.data?.type === 'shopeers.erp.sessionState'
            && ['authenticated', 'login_required'].includes(event.data.state)
            && [...document.querySelectorAll('iframe')].some(frame => frame.contentWindow === event.source)) {
            erpSessionState = event.data.state;
            renderPageContext();
            void reportExtensionStatus();
            return;
        }
        if (isTopFrame || event.source !== window.top || !supportedErpUrl(event.origin)
            || event.data?.type !== 'shopeers.erp.openCostPreview' || !isPurchasePage()) return;
        createUi();
        openPanel();
    });

    initWhenReady();
    window.dispatchEvent(new CustomEvent('shopeers:erp-v8-session-replay-request'));
    schedulePageSizeUpgrade();
    reportExtensionStatus();
    window.setInterval(reportExtensionStatus, 15000);
    console.info(PREFIX, `v${EXTENSION_VERSION} 已在卓麟 ERP 启动`);
}());
